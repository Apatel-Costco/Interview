﻿using GraphDemo.Model;
using HotChocolate;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraphDemo.Entities
{
    public class OrderQueries
    {
        public async Task<List<Orders>> GetOrders([Service] OMSOrdersContext context, long customerId) =>
            await context
                .OrderHeaders
                .Where(w => w.CustomerId == customerId)
                .OrderBy(o => o.OrderedDate)
                .ToListAsync();
    }
}